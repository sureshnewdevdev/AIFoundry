"""
hello_foundry.py
================
The simplest possible "use Azure Foundry from Python" example.
Send one prompt, print the model's answer.

Run it:  python hello_foundry.py
"""

import foundry_client as fc


def main():
    question = "In one sentence, what is Microsoft Foundry?"

    if not fc.is_live():
        print("OFFLINE MODE — no AZURE_AI_PROJECT_ENDPOINT configured.\n")
        print("To go live:")
        print("  1. Copy .env.example to .env and fill in your endpoint + model.")
        print("  2. Run:  az login")
        print("  3. Run:  python hello_foundry.py\n")
        print(f"(Once live, this would ask the model: {question!r})")
        return

    print(f"Asking Foundry ({fc.MODEL}): {question}\n")
    answer = fc.ask(question)
    print("Foundry says:")
    print(answer)


if __name__ == "__main__":
    main()
