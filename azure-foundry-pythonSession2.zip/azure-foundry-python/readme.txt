========================================================================
 USING AZURE FOUNDRY FROM PYTHON  —  Amazon Settlement Reconciliation
========================================================================

The code version of the no-code Foundry workflow (Planner-Executor).
Five roles: Ingestion, Extraction, Rule match, Smart match — driven from
Python. The deterministic rule matching is exact and repeatable, which is
the one thing the portal demo could not guarantee.

It RUNS OUT OF THE BOX with no Azure account (offline mode), then goes
LIVE against a real Foundry model the moment you add your endpoint.

------------------------------------------------------------------------
 REQUIREMENTS
------------------------------------------------------------------------
- Python 3.11.0   (see the .python-version file; other 3.x may work but
  3.11.0 is the supported version for this project)
- For LIVE mode only: an Azure subscription with a Foundry project and a
  deployed model, plus the Azure CLI (for "az login").

------------------------------------------------------------------------
 QUICK START  (offline — zero setup)
------------------------------------------------------------------------
1. Make sure you are on Python 3.11.0:
       python --version

2. (Recommended) create a virtual environment:
       python -m venv .venv
       # Windows:        .venv\Scripts\activate
       # macOS / Linux:  source .venv/bin/activate

3. Run it — no packages or credentials needed for offline mode:
       python run.py

   You will see all five stages run and the five orders resolved,
   including the SO-1002 escalation to a human.

------------------------------------------------------------------------
 GO LIVE  (use a real Foundry model)
------------------------------------------------------------------------
1. Install the dependencies:
       pip install -r requirements.txt

2. Copy the environment template and fill it in:
       # Windows:        copy .env.example .env
       # macOS / Linux:  cp .env.example .env

   Edit .env and set:
       AZURE_AI_PROJECT_ENDPOINT=https://<resource>.ai.azure.com/api/projects/<project>
       MODEL_DEPLOYMENT=gpt-4o-mini      (or your deployed model name)

   The endpoint is shown on your project's home page in the Foundry portal.

3. Sign in once:
       az login

4. Run again — now the Smart match step reasons with the Foundry model:
       python run.py

       python run.py hello     <- simplest one-prompt example

------------------------------------------------------------------------
 FILE TOUR
------------------------------------------------------------------------
  run.py                 Entry point. Runs the demo (or "hello").
  hello_foundry.py       Simplest example: send one prompt, print reply.
  settlement_demo.py     The five-stage reconciliation pipeline.
  foundry_client.py      Thin SDK wrapper (handles offline vs live).
  data/                  Sample Amazon settlement file (one file, no
                         other services needed).
  requirements.txt       Python dependencies.
  .env.example           Copy to .env for live mode.
  .python-version        Pins Python 3.11.0.

------------------------------------------------------------------------
 HOW IT MAPS TO THE PORTAL DEMO
------------------------------------------------------------------------
  Portal (no-code)              This project (code)
  ----------------------------  ----------------------------------------
  Workflow canvas (the plan)    the main() pipeline in settlement_demo.py
  Ingestion agent               ingest()
  Extraction agent              extract()
  Rule match agent              rule_match()   <- exact, in code
  Smart match agent             smart_match()  <- Foundry model when live
  Model output varies run/run   deterministic rules never drift

------------------------------------------------------------------------
 WHAT YOU SHOULD SEE
------------------------------------------------------------------------
  SO-1001  MATCHED       exact 3-way match
  SO-1003  MATCHED       refund, exact amount
  SO-1002  ESCALATE_HITL promotion gap, 17.9% (> 5%)
  SO-1004  AUTO_RESOLVED EUR -> USD, 0% variance
  SO-1005  AUTO_RESOLVED 0.8% fee gap, within tolerance

------------------------------------------------------------------------
 TROUBLESHOOTING
------------------------------------------------------------------------
- "Foundry endpoint not configured": you are in offline mode. That is
  fine for trying the code. Set AZURE_AI_PROJECT_ENDPOINT in .env to go live.
- Auth errors (401/403): run "az login" and confirm your account has
  access to the Foundry project and the deployed model.
- Import errors for azure-*: run "pip install -r requirements.txt". These
  are only needed for LIVE mode.
- Wrong Python version warning: install Python 3.11.0 and recreate .venv.

------------------------------------------------------------------------
 NOTE ON VERSIONS
------------------------------------------------------------------------
The Foundry Python SDK is evolving quickly. This project uses the
azure-ai-projects 2.x pattern (AIProjectClient -> get_openai_client ->
responses.create). If a call signature changes in a newer release, check
the current quickstart at:
  https://learn.microsoft.com/azure/foundry/quickstarts/get-started-code
========================================================================
