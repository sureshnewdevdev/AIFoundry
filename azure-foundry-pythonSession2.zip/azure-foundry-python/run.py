"""
run.py — entry point
====================
    python run.py          # runs the settlement reconciliation demo
    python run.py hello    # runs the simplest one-prompt Foundry example

Targets Python 3.11.0.
"""

import sys


def _check_python():
    major, minor = sys.version_info[:2]
    if (major, minor) != (3, 11):
        print(f"[note] This project targets Python 3.11.0. You are on "
              f"{major}.{minor}.{sys.version_info[2]}. It will usually still run,")
        print("       but use 3.11.0 (see .python-version) to match the trainer setup.\n")


def main():
    _check_python()
    arg = sys.argv[1].lower() if len(sys.argv) > 1 else "demo"
    if arg == "hello":
        import hello_foundry
        hello_foundry.main()
    else:
        import settlement_demo
        settlement_demo.main()


if __name__ == "__main__":
    main()
