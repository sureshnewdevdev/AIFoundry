"""
foundry_client.py
=================
A tiny wrapper around the Microsoft Foundry Python SDK.

Goal: make the rest of the code work whether or not Azure is configured.
- If AZURE_AI_PROJECT_ENDPOINT is set, calls run against the real Foundry model.
- If it is NOT set, the code runs in OFFLINE mode so you can try everything
  with zero setup, and each caller falls back to local logic.

The only two functions you need:
    is_live()          -> True if a Foundry endpoint is configured
    ask(prompt, system)-> str response from the Foundry model (live mode only)
"""

import os

# Load a .env file if python-dotenv is installed (optional, just convenience).
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

ENDPOINT = os.getenv("AZURE_AI_PROJECT_ENDPOINT", "").strip()
MODEL = os.getenv("MODEL_DEPLOYMENT", "gpt-4o-mini").strip()

_openai = None


def is_live() -> bool:
    """True when a Foundry project endpoint is configured."""
    return bool(ENDPOINT)


def _get_openai():
    """Build (once) the OpenAI-style client that talks to Foundry."""
    global _openai
    if _openai is None:
        # Imported lazily so OFFLINE mode needs no azure packages installed.
        from azure.identity import DefaultAzureCredential
        from azure.ai.projects import AIProjectClient

        project = AIProjectClient(
            endpoint=ENDPOINT,
            credential=DefaultAzureCredential(),
        )
        _openai = project.get_openai_client()
    return _openai


def ask(prompt: str, system: str | None = None) -> str:
    """
    Send a prompt to the deployed Foundry model and return the text response.
    Raises RuntimeError if called while offline (no endpoint configured).
    """
    if not is_live():
        raise RuntimeError("Foundry endpoint not configured (offline mode).")

    openai = _get_openai()
    text = prompt if not system else f"{system}\n\n{prompt}"
    response = openai.responses.create(model=MODEL, input=text)
    return response.output_text
