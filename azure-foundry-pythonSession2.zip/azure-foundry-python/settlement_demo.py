"""
settlement_demo.py
==================
The Python (code) version of the no-code Foundry workflow you built.

Same five roles as the portal demo:
    Ingestion  -> validate the file
    Extraction -> parse one net record per order
    Rule match -> deterministic 2-way / 3-way matching (EXACT, in code)
    Smart match-> reasoning for the leftovers (Foundry model when live)

Why this matters: the Rule match here is exact and repeatable to the cent,
which is the one thing the no-code demo could not guarantee.

Run it:  python settlement_demo.py     (or: python run.py)
Targets: Python 3.11.0
"""

import os
from decimal import Decimal, ROUND_HALF_UP

import foundry_client as fc

MONEY = Decimal("0.01")
DATA_FILE = os.path.join(os.path.dirname(__file__), "data", "sample_amazon_settlement.txt")

# Reference data (stands in for Dynamics 365 sales orders + shipments + FX).
SALES_ORDERS = {
    "111-2223334-4445556": ("SO-1001", Decimal("17.74"), "USD"),
    "111-3334445-5556667": ("SO-1002", Decimal("27.98"), "USD"),
    "111-4445556-6667778": ("SO-1003", Decimal("-21.24"), "USD"),
    "111-5556667-7778889": ("SO-1004", Decimal("23.65"), "USD"),
    "111-6667778-8889990": ("SO-1005", Decimal("33.00"), "USD"),
}
SHIPMENTS = {
    "111-2223334-4445556", "111-3334445-5556667",
    "111-5556667-7778889", "111-6667778-8889990",
}
FX_TO_USD = {"USD": Decimal("1.00"), "EUR": Decimal("1.10")}
HITL_THRESHOLD_PCT = Decimal("5.0")

EXPECTED_HEADER = [
    "settlement-id", "order-id", "sku", "asin", "transaction-type",
    "amount-type", "amount-description", "amount", "currency", "quantity", "posted-date",
]


def money(x) -> Decimal:
    return Decimal(str(x)).quantize(MONEY, rounding=ROUND_HALF_UP)


# ---- Stage 1: Ingestion -------------------------------------------------
def ingest(path: str) -> list[dict]:
    import csv
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f, delimiter="\t")
        if reader.fieldnames != EXPECTED_HEADER:
            raise ValueError(f"Unexpected columns: {reader.fieldnames}")
        rows = list(reader)
    if not rows:
        raise ValueError("Settlement file is empty.")
    print(f"[1] Ingestion    : {len(rows)} line items, schema OK.")
    return rows


# ---- Stage 2: Extraction ------------------------------------------------
def extract(rows: list[dict]) -> list[dict]:
    orders: dict[str, dict] = {}
    for r in rows:
        oid = r["order-id"]
        o = orders.setdefault(oid, {
            "order_id": oid, "asin": r["asin"], "currency": r["currency"],
            "net": Decimal("0.00"), "promotions": Decimal("0.00"), "refund": False,
        })
        o["currency"] = r["currency"]
        if r["transaction-type"] == "Refund":
            o["refund"] = True
        amt = money(r["amount"])
        o["net"] += amt
        if r["amount-description"] == "Promotion":
            o["promotions"] += amt
    for o in orders.values():
        o["net"] = money(o["net"])
    print(f"[2] Extraction   : {len(orders)} orders extracted.")
    return list(orders.values())


# ---- Stage 3: Rule match (deterministic, EXACT) -------------------------
def rule_match(order: dict) -> tuple[str, str]:
    so = SALES_ORDERS.get(order["order_id"])
    if not so:
        return "UNRESOLVED", "no sales order"
    so_id, expected, currency = so
    if order["currency"] != currency:
        return "UNRESOLVED", f"currency {order['currency']} vs {currency}"
    if order["net"] != expected:
        return "UNRESOLVED", f"gap {order['net']} vs {expected} ({so_id})"
    three_way = order["order_id"] in SHIPMENTS
    tag = "3-way" if three_way else "2-way"
    return "MATCHED", f"exact {tag} match to {so_id}"


# ---- Stage 4: Smart match (reasoning) -----------------------------------
def _variance_pct(actual: Decimal, expected: Decimal) -> Decimal:
    base = abs(expected) if expected != 0 else Decimal("1")
    return (abs(actual - expected) / base * Decimal("100")).quantize(Decimal("0.1"))


def smart_match_offline(order: dict) -> str:
    """Local heuristic used when no Foundry endpoint is configured."""
    so_id, expected, currency = SALES_ORDERS[order["order_id"]]
    if order["currency"] != currency:
        converted = money(order["net"] * FX_TO_USD[order["currency"]] / FX_TO_USD[currency])
        var = _variance_pct(converted, expected)
        decision = "AUTO_RESOLVED" if var <= HITL_THRESHOLD_PCT else "ESCALATE_HITL"
        return f"{decision} | {order['net']} {order['currency']} -> {converted} {currency}, {var}% vs {so_id}"
    gap = money(order["net"] - expected)
    var = _variance_pct(order["net"], expected)
    if order["promotions"] != 0 and abs(gap - order["promotions"]) <= Decimal("0.01"):
        decision = "AUTO_RESOLVED" if var <= HITL_THRESHOLD_PCT else "ESCALATE_HITL"
        return f"{decision} | gap {gap} = promotion {order['promotions']}, {var}% vs {so_id}"
    if var <= HITL_THRESHOLD_PCT:
        return f"AUTO_RESOLVED | minor fee variance {gap} ({var}%) within 5% vs {so_id}"
    return f"ESCALATE_HITL | unexplained gap {gap} ({var}%) vs {so_id}"


def smart_match(order: dict) -> str:
    """Use the Foundry model when live; fall back to the local heuristic."""
    if not fc.is_live():
        return smart_match_offline(order)

    so_id, expected, currency = SALES_ORDERS[order["order_id"]]
    system = (
        "You are a settlement reconciliation reasoning agent. "
        "Decide if an order gap can be auto-resolved (<=5% variance) or must escalate to a human. "
        "Consider currency conversion (1 EUR = 1.10 USD), seller-funded promotions, and small fee/rounding gaps. "
        "Reply on ONE line as: DECISION | reason  where DECISION is AUTO_RESOLVED or ESCALATE_HITL."
    )
    prompt = (
        f"Order {order['order_id']} ({so_id}): "
        f"Amazon net = {order['net']} {order['currency']}, "
        f"expected = {expected} {currency}, promotions = {order['promotions']}."
    )
    try:
        return fc.ask(prompt, system=system).strip().splitlines()[0]
    except Exception as e:
        return smart_match_offline(order) + f"  (fell back: {e})"


# ---- Pipeline -----------------------------------------------------------
def main():
    mode = "LIVE (Foundry)" if fc.is_live() else "OFFLINE (local reasoning)"
    print(f"\nAmazon settlement reconciliation  —  mode: {mode}\n" + "-" * 52)

    rows = ingest(DATA_FILE)
    orders = extract(rows)

    print("[3] Rule match   :")
    unresolved = []
    for o in orders:
        status, reason = rule_match(o)
        print(f"      {o['order_id']}  {status:11} {reason}")
        if status != "MATCHED":
            unresolved.append(o)

    print("[4] Smart match  :  (only the leftovers)")
    for o in unresolved:
        print(f"      {o['order_id']}  {smart_match(o)}")

    print("-" * 52)
    print("Deterministic rules cleared the clean orders; reasoning handled the")
    print("exceptions; anything above 5% variance is escalated to a human.\n")


if __name__ == "__main__":
    main()
