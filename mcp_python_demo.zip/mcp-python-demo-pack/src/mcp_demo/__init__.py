"""MCP Python demo package."""

